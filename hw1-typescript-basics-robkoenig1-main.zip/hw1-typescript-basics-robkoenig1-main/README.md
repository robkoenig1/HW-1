# Homework 1 - TypeScript Basics
